package org.launchcode.codingevents;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodingEventsApplicationTests {

	@Test
	void contextLoads() {
	}

}
